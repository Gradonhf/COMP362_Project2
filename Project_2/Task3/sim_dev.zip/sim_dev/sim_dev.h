#ifndef __SIM_DEV_H_
#define __SIM_DEV_H_

#define IOCTL_SIM_DEV_WRITE _IOR(0, 1, int)
#define IOCTL_SIM_DEV_READ _IOR(0, 2, int)

#endif

